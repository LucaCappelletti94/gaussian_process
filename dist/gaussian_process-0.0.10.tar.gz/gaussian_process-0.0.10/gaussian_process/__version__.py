"""Current version of package gaussian_process"""
__version__ = "0.0.10"